package View;

/**
 * Created by Aviadjo on 6/14/2017.
 */
public interface IView {
    void displayMaze(int[][] maze);

}
